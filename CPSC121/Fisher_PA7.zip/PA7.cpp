/*
Name: Lauren Fisher
Class: CPSC121
Date: 04/03/19
Assignment: PA7
Description: This program utilizes functions and arrays to play a game of hangman until the user guesses the word or runs out of attempts.
Notes: I H8 Functions :)
*/
#include "hangman.h"


/*********************************************************************
Function:void printGameRules()
Date Created: 04/03/19
Date Last Modified:04/03/19
Description: Displays game rules for hangman
Input Parameters: none
Returns: none
**********************************************************************/
void printGameRules() {
	cout << "Great! The rules of hangman are quite simple. I will have a word with a certain number of letters hidden to you by dashes (-----). Then you will have 7 guesses to either guess a letter in the word or guess the word itself. You may not guess the same letter twice and if you fail to guess the word by the end of 7 guesses your little hangman.... well... dies :/." << endl;
	}
/*********************************************************************
Function:void int fillWordsArray(string fileWords[])
Date Created: 04/03/19
Date Last Modified:04/03/19
Description: opens file, reads in words as an array
Input Parameters: string file[words]
Returns: int numWords 
**********************************************************************/	
int fillWordsArray(string fileWords[]) {
	string word = " ";
	ifstream inputFile;
	int i = 0;
	int numWords = 0;

	
	
	inputFile.open("words.txt");
	if(inputFile.fail()) {
		cout << "Failed to open the input file." << endl;
		exit(-1);
	}
	while(!inputFile.eof()) {
		getline(inputFile, word);
			if(inputFile.good()) {
				cout << word << " " << endl;
				fileWords[numWords] = word;
				numWords++;
			}
	}
	
	return numWords;

}

/*********************************************************************
Function:string generateRandomWord(string fileWords[NUM_WORDS], int numWords)
Date Created: 04/03/19
Date Last Modified:04/03/19
Description: generates a random word from input file
Input Parameters: file words array and numWords
Returns: secretWprd
**********************************************************************/
string generateRandomWord(string fileWords[NUM_WORDS], int numWords) {
	
	string secretWord = " ";
	
	secretWord = fileWords[rand() % numWords];
	
	return secretWord;

	}
/*********************************************************************
Function:char userInputGuess()
Date Created: 04/03/19
Date Last Modified:04/03/19
Description: takes in userGuess
Input Parameters: none
Returns: userGuess
**********************************************************************/

char userInputGuess() {
	char userGuess = ' ';
	
	cout << "Please enter a singular letter as a guess." << endl;
	cin >> userGuess;
	
	return userGuess;
	}
/*********************************************************************
Function:void printArray(char arr[], int size)
Date Created: 04/03/19
Date Last Modified:04/03/19
Description: prints any of our arrays when called
Input Parameters: array and size of array
Returns: none
**********************************************************************/	
void printArray(char arr[], int size) {
	int i = 0;
		for(i = 0; i < size; i++) {
			cout << arr[i] << " ";
			}
			cout << endl;
	}
/*********************************************************************
Function:void printVisibleLetters(char alphabet[], char userGuess)
Date Created: 04/03/19
Date Last Modified:04/03/19
Description: creates space in alphabet array when guessed
Input Parameters: alphabet array and userGuess
Returns: void
**********************************************************************/
void printVisibleLetters(char alphabet[], char userGuess) {
	int i = 0;
	
	for(i = 0; i < NUM_LETTERS; i++) {
		if(userGuess == alphabet[i]) {
			alphabet[i] = ' ';
			}
	}
	cout << endl;
	}
/*********************************************************************
Function:int generateWordSize(string secretWord)
Date Created: 04/03/19
Date Last Modified:04/03/19
Description: generates word size of secret word
Input Parameters: string secretWord
Returns: int wordSize
**********************************************************************/
int generateWordSize(string secretWord) {
	int wordSize = 0;
	
	wordSize = secretWord.size();
	
	return wordSize;
	}
/*********************************************************************
Function:void dashArrayFunction(int wordSize, string secretWordArr[])
Date Created: 04/03/19
Date Last Modified:04/03/19
Description: copies character array to dashes and displays
Input Parameters: wordsize and secretWord array
Returns: none
**********************************************************************/	
void dashArrayFunction(int wordSize, string secretWordArr[]) {
	char dashArray[wordSize];
	int i = 0;
	
	for(i = 0; i < wordSize; i++) {
		secretWordArr[i] = '-';
		dashArray[i] = secretWordArr[i];
		cout << dashArray[i];
	} 
}
/*********************************************************************
Function:void secretWordArray(int wordSize, string secretWord) 
Date Created: 04/03/19
Date Last Modified:04/03/19
Description: puts string word into character array
Input Parameters: wordsize and secret word
Returns: none
**********************************************************************/
void secretWordArray(int wordSize, string secretWord) {
	int i = 0;
	char secretWordArray[wordSize];
	
	for(i = 0; i < wordSize; i++) {
		secretWordArray[i] = secretWord[i];
		}
}
/*********************************************************************
Function:bool userCorrectness(char userGuess, char secretWordArr[], int wordSize)
Date Created: 04/03/19
Date Last Modified:04/03/19
Description: determines if user is incorrect or correct
Input Parameters: userGuess, secretWord array, wordSize
Returns: bool true or false
**********************************************************************/
bool userCorrectness(char userGuess, char secretWordArr[], int wordSize){
	int i = 0;
	bool existed = false
	for(int i = 0; i < wordSize; i++) {
		if(userGuess == secretWordArr[i]) {
			existed = true;
		}
	return existed;
	}
}
/*********************************************************************
Function:int userCorrect(bool existed)
Date Created: 04/03/19
Date Last Modified:04/03/19
Description: displays user is correct
Input Parameters: bool 
Returns: amlunt of correct guesses
**********************************************************************/
int userCorrect(bool existed) {
	if(existed) {
		cout << "Correct!" << endl;
		k++;
		}
		return k;
	}
/*********************************************************************
Function:int userInorrect(bool existed)
Date Created: 04/03/19
Date Last Modified:04/03/19
Description: displays user is incorrect
Input Parameters: bool
Returns: amount of incorrect guesses, j
**********************************************************************/
int userInorrect(bool existed) {
	if(!existed) {
		cout << "Incorrect!" << endl;
		j++;
		}
		return j;
	}
/*********************************************************************
Function:bool userInputIsGood(string userGuess, char alphabet[])
Date Created: 04/03/19
Date Last Modified:04/03/19
Description: determines if user guessed letter before
Input Parameters: userGuess and alphabet array
Returns: true bool or false bool
**********************************************************************/
bool userInputIsGood(string userGuess, char alphabet[]) {
	bool userInputGood = false;
	for(i = 0; i < NUM_LETTERS; i++) {
		if(userGuess != alphabet[]) {
			userInputGood = false;
			}
		if(userGuess == alphabet[]) {
			userInputGood = true;
			}
		}
		return userInputGood;
	}
		




