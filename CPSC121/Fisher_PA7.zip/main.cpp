/*
Name: Lauren Fisher
Class: CPSC121
Date: 04/03/19
Assignment: PA7
Description: This program utilizes functions and arrays to play a game of hangman until the user guesses the word or runs out of attempts.
Notes: I H8 Functions :)
*/

#include <iostream>
#include <cstring>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include "hangman.h"

using namespace std;

int main() {

srand(time(0));

string userPlay = " ";
ifstream inputFile;
string fileWords[NUM_WORDS];
int numWords = 0;
int i = 0;
string word = " ";
char alphabet[] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};
string secretWord = " ";
int wordSize = 0;
char userGuess = ' ';
bool existed = false;
int j = 0;
int k = 0;
char dashArray[wordSize];
char secretWordArr[wordSize];
bool userInputGood = false;




cout << "Welcome to the game of hangman! A game of luck and skill in which the fate of a life will lie in your two very own hands. Would you like to play? Enter Y for Yes or N for No." << endl;

cin >> userPlay;

if(userPlay == "Y") {
	printGameRules();
	}
if(userPlay == "N") {
	cout << "Too bad!" << endl;
	exit(-1);
	}



numWords = fillWordsArray(fileWords);

cout << numWords;

cout << fileWords[numWords];

cout << "\n\n\n\n\n";

secretWord = generateRandomWord(fileWords, numWords);

wordSize = generateWordSize(secretWord);

printArray(dashArray, wordSize);

printArray(alphabet, NUM_LETTERS);
			

do{

userGuess = userInputGuess();

userInputGood = userInputIsGood(userGuess, alphabet);

while(userInputGood) {
	userGuess = userInputGuess();
	}

secretWordArray(secretWord, wordSize);

dashArrayFunction(wordSize, secretWordArr);

userCorrectness(userGuess, secretWordArr[], wordSize)

userCorrect(existed);
userIncorrect(existed);

numTries = 7 - j;

cout << "You have " << numTries << "left!";

printArray(dashArray, wordSize);

printArray(alphabet, NUM_LETTERS);

	
}while((k < wordSize) && (j <= 7));


inputFile.close();

return 0;
}

