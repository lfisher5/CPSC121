/*
Name: Lauren Fisher
Class: CPSC121
Date: 04/03/19
Assignment: PA7
Description: This program utilizes functions and arrays to play a game of hangman until the user guesses the word or runs out of attempts.
Notes: I H8 Functions :)
*/

#ifndef HANGMAN_H
#define HANGMAN_H

#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>
#include <ctime>

using namespace std;

const int NUM_WORDS = 100; //MAX number of words in the file
const int NUM_LETTERS = 26;//alphabet letters

void printGameRules();

int fillWordsArray(string fileWords[]);

string generateRandomWord(string fileWords[], int numWords);

void printVisibleLetters(char alphabet[], char userGuess);

int generateWordSize(string secretWord);

void secretWordArray(string secretWord, int wordSize);

char userInputGuess();

void printArray(char[], int);

void dashArrayFunction(int, char[]);

bool userCorrectness(char userGuess, char secretWordArr[], int wordSize);

int userCorrect(bool);

int userIncorrect(bool);

bool userInputIsGood(string userGuess, char alphabet[]);


#endif







