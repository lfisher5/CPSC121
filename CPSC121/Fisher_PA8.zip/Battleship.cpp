
/*
Name: Lauren Fisher
Class: CPSC 121
Date: 04/17/19
PA: 8
Description: This program simulates a 2 player game of battleship with a computer as player 2.
Notes: Sorry that sometimes the program is left hanging, if you click enter it will work. 
*/
#include "Battleship.h"
/***************************************************
*Function: displayGameRules()
*Created: 04/11/19
*Description: displays game rules at beginning of program
*
*Parameters: none
*Returns: none
*
****************************************************/
void displayGameRules() {
	cout << "**********************************************************\n\tWELCOME TO BATTLESHIP\n**********************************************************" << endl;

cout << "\n\n\n\n Battleship is a 2-player game with the other player being the computer in which each of you will place 5 different ships of varying size on a 10x10 grid and then take turns trying to hit eachothers ships one coordinate at a time untill all units of all the ships have been ""sunk"". Good luck!\n\n\n" << endl;

}

/***************************************************
*Function: waitFor userInput()
*Created: 04/11/19
*Description: is a press enter to continue function to have in between turns
*
*Parameters: none
*Returns: none
*
****************************************************/

void waitForUserInput() {
	cout << "Press enter to continue." << endl;
	cin.get();
	}

/***************************************************
*Function: printArray()
*Created: 04/11/19
*Description: accepts a 2D array and prints it in a grid
*
*Parameters: 2D array, rows, columns
*Returns: none
*
****************************************************/

void printArray(const char arr[NUM_ROWS][NUM_COLS], int rows, int cols) {
	int i, j;
//most used function
	cout << " ";
	for(i = 0; i < 10; i++) {
		cout << i << " ";
		}
		cout << endl;
	for (i = 0; i < rows; i++) {
		cout << i;
		for (j = 0; j < cols; j++) {
			
			cout << arr[i][j] << " ";
		}
		cout << endl;
	}

}

/***************************************************
*Function: fillArray()
*Created:04/11/19
*Description: fills any 2D array and fills it with -'s in a grid
*
*Parameters: 2D array, rows, cols
*Returns: none
*
****************************************************/

void fillArray(char arr[NUM_ROWS][NUM_COLS], int rows, int cols) {
	int i, j;
	
	// outer loop iterates over each row
	for (i = 0; i < rows; i++) {
		// inner loop iterates over int in arr[i] (row)
		for (j = 0; j < cols; j++) {
			arr[i][j] = '-';
		}
	}
}

/***************************************************
*Function: getManualShipPlacement()
*Created: 04/13/19
*Description: accepts 2D array, accepts user input for coordinates to place ship 
* over and then puts that ship's symbol on the board instead
*Parameters: 2D array
*Returns:none
*
****************************************************/

void getManualShipPlacement(char p1SolutionGrid[NUM_ROWS][NUM_COLS]) {
	int i = 0;
	int j = 0;
	int k = 0;
	int y = 0;
	int x = 0;
	string input;
	int shipCoords[10];
	bool shipCheck = false;
	
	for(i = 0; i < NUM_SHIPS; i++) {
		do {
		cout << "Please enter " << shipSizes[i] << " coordinates for the " << shipNames[i] << " to be placed across." << endl;
		shipCheck = true;
		for(k = 0; k < (shipSizes[i] * 2); k += 2) {
			cin >> x >> y;
			input[k] = x;
			input[k + 1] = y;
		if(p1SolutionGrid[x][y] != '-') {
				shipCheck = false;
			}
		}
		if(!shipCheck) {
			cout << "Invalid Coordinates." << endl;
			}
		
	}while(shipCheck == false);// if corrdinates are invalid
		for(k = 0; k < shipSizes[i] * 2; k += 2) {
			p1SolutionGrid[input[k]][input[k+1]] = shipSymbols[i];
			}
	}
	
}

/***************************************************
*Function: randomlyPlaceShips()
*Created: 04/17/19
*Description: accepts 2D array, randomly chooses orientation and starting coordinate and increments by shipSize and places characters for a given ship
*
*Parameters: 2D array
*Returns: none
*
****************************************************/

void randomlyPlaceShips(char arr[NUM_ROWS][NUM_COLS]) {
	int x, y, i, j;
	bool shipOrientation, shipHorizontal, shipCheck;
	
	shipCheck = true;
	for(i = 0; i < NUM_SHIPS; i++) {
		shipOrientation = rand() % 2;
		if(shipOrientation == 1) {
			shipHorizontal = true;
		}
		if(shipOrientation == 0) {
			shipHorizontal = false;
		}
		if(shipHorizontal == false) {
			do{
			shipCheck = true;
			y = rand() % (10 - shipSizes[i] + 1); 
			x = rand() % 10;
			
			for(j = y; j < (y + shipSizes[i]); j++) {
				if(arr[x][j] != '-') {
					shipCheck = false;
					}
	
				}
			}while(shipCheck == false);
			
			for(j = y; j < (y + shipSizes[i]); j++) {
				arr[x][j] = shipSymbols[i];
			}

		}
		if(shipHorizontal == true) {
			do{
			shipCheck = true;
			x = rand() % (10 - shipSizes[i] + 1); 
			y = rand() % 10;
			for(j = x; j < (x + shipSizes[i]); j++) {
					if(arr[j][y] != '-') {
						shipCheck = false;
						}
					}
			}while(shipCheck == false);
			
			for(j = x; j < (x + shipSizes[i]); j++) {
				arr[j][y] = shipSymbols[i];
				}
			}
		}
	}
		
/***************************************************
*Function: setP2GridEqualToBlank()
*Created: 04/17/19
*Description: makes empty grid displayed to user parallel to p2SolutionGrid
*
*Parameters: p2SolutionGrid, and emptyP2Grid
*Returns:
*
****************************************************/
		
void setP2GridEqualToBlank(char p2SolutionGrid[NUM_ROWS][NUM_COLS], char emptyP2Grid[NUM_ROWS][NUM_COLS]) {
	int i, j;
	
	for(i = 0; i < NUM_ROWS; i++) {
		
		for(j = 0; j < NUM_COLS; j++) {
			emptyP2Grid[i][j] = p2SolutionGrid[i][j];
			if(p2SolutionGrid[i][j] != '-') {
				emptyP2Grid[i][j] = '-';
				}
			
			}
		}
		
	}
	
/***************************************************
*Function: checkShipSunk()
*Created: 04/17/19
*Description: checks array of number of times ship has been hit and compares to shipsize to tell if the ship is sunk and if the game is won
*
*Parameters: 2D array, shipHits array, ouputFile
*Returns:bool winner
*
****************************************************/
	
bool checkShipSunk(char arr[NUM_ROWS][NUM_COLS], int shipsHitP1[5], ofstream& outputFile) {
	bool winner;
	int shipSunk;
	int i, j, k;
	
	for(i = 0; i < NUM_SHIPS; i++) {
		if(shipsHitP1[i] == shipSizes[i]) {
			outputFile << shipNames[i] << " is sunk!" << endl; 
			cout << shipNames[i] << " is sunk!" << endl; 
			
			}
		for(j = 0; j < NUM_ROWS; j++) {
			for(k = 0; k < NUM_COLS; k++) {
				if(arr[j][k] == shipSymbols[i]) {	
					winner = false;
					}
				else{
					winner = true;
					outputFile << "Winner!" << endl;
					}	
			}
		
		}	
	}
	return winner;

}

/***************************************************
*Function: getShotPlayer()
*Created: 04/13/19
*Description: updates memory for player shot
*
*Parameters:2D array, x and y passed by reference
*Returns: none
*
****************************************************/

int getShotPlayer(char p2SolutionGrid[NUM_ROWS][NUM_COLS], int& x, int& y) {

	
	cout << "Please enter coordinates for shot at computer's board" << endl;
	cin >> x;
	cin >> y;
	

	}

/***************************************************
*Function: getShotComputer()
*Created: 04/13/19
*Description: simulates random shot by computer for x and y
*
*Parameters: x and y by reference
*Returns: none
*
****************************************************/

int getShotComputer(int& x, int& y) {
	
	x = rand() % 10;
	y = rand() % 10;
	 
	}

/***************************************************
*Function: checkShot
*Created: 04/14/19
*Description: checks shot for miss or hit and changes spot on board accordingly
*
*Parameters: 2D array, x and y by reference, ouputFile, hits, misses, and shots, a shipsHit array, and another 2D array
*Returns: bool
*
****************************************************/
	
bool checkShot(char arr[NUM_ROWS][NUM_COLS], int& x, int& y, ofstream& outputFile, int& hits, int& misses, int& shots, int shipsHitP1[5], char arr2[NUM_ROWS][NUM_COLS]) {


	bool shipHit;
	char shipCharacter;
	int shipIndexNumber;

/*do{// how to get loop of shot while it hasn't been done yet
getShotPlayer(arr2, x, y);

}while((arr2[x][y] == 'm') || (arr2 == '*'));*/
cout << "X: " << x << " Y: " << y << endl;
	
	if(arr[x][y] == '-') {
		cout << "Miss!" << endl;
		outputFile << "Shot: " << x << ", " << y << endl;
		outputFile << "Miss!"<< endl;
		misses++;
		shots++;
		arr2[x][y] = 'm';
		}
	else if(arr[x][y] != '-') {
		shipCharacter = arr[x][y];
		shipIndexNumber = shipIndex(shipCharacter);
		shipsHitP1[shipIndexNumber]++;
		cout << "Hit!" << endl;
		outputFile << "Shot: " << x << ", " << y << endl;
		outputFile << "Hit!"<< endl;
		hits++;
		shots++;
		arr2[x][y] = '*';
		}
		return shipHit;
	}
	
/***************************************************
*Function: playerTurn()
*Created:04/14/19
*Description: calls all functions required to do one full turn of user
*
*Parameters: 2D array, 2D array, empty 2D array, x and y, ouputFile, hits, misses,
* shots, and shipHits array
*Returns:none
*
****************************************************/

void playerTurn(char p1SolutionGrid[NUM_ROWS][NUM_COLS], char p2SolutionGrid[NUM_ROWS][NUM_COLS], char emptyP2Grid[NUM_ROWS][NUM_COLS], int x, int y, ofstream& outputFile, int& hits, int& misses, int& shots, int shipsHitP1[5]) {
	cout << "\n\n\nComputer's Board: " << endl;
	printArray(emptyP2Grid, NUM_ROWS, NUM_COLS);
	cout << "Player 1's Turn: " << endl;
	
	getShotPlayer(p2SolutionGrid, x, y);
		
	//do {
	//getShotPlayer(p2SolutionGrid);
	outputFile << "Player 1: " << endl;	
	//}while((p2SolutionGrid[x][y] == 'm') || (p2SolutionGrid == '*'));
	checkShot(p2SolutionGrid, x, y, outputFile, hits, misses, shots, shipsHitP1, emptyP2Grid);
	//checkShipSunk(p2SolutionGrid);
	printArray(emptyP2Grid, NUM_ROWS, NUM_COLS);
	checkShipSunk(p2SolutionGrid, shipsHitP1, outputFile);
}

/***************************************************
*Function: computerTurn()
*Created: 04/14/19
*Description: calls all functions necessary to complete computer's turn
*
*Parameters: 2D array, 2D array, empty 2D array, x and y, ouputFile, hits, misses,
* shots, and shipHits array
*Returns: none
*
****************************************************/

void computerTurn(char p1SolutionGrid[NUM_ROWS][NUM_COLS], char emptyP2Grid[NUM_ROWS][NUM_COLS], int x, int y, ofstream& outputFile, int& hits, int& misses, int& shots, int shipsHitP2[5]) {

	cout << "Computer's Turn: " << endl;
	getShotComputer(x, y);
	outputFile << "Player 2: " << endl;
	checkShot(p1SolutionGrid, x, y, outputFile, hits, misses, shots, shipsHitP2, p1SolutionGrid);
	printArray(p1SolutionGrid, NUM_ROWS, NUM_COLS);
	checkShipSunk(p1SolutionGrid, shipsHitP2, outputFile);
}
	
/***************************************************
*Function: shipIndex()
*Created:04/17/19
*Description: finds shipIndex for shipCharacter hit
*
*Parameters: shipCharacter
*Returns: i or nothing
*
****************************************************/
	
int shipIndex(char shipCharacter) {
	int i;
	
	for(i = 0; i < NUM_SHIPS; i++) {
		if(shipSymbols[i] == shipCharacter) {
			return i;
			}
		}
		return -1;
}

/***************************************************
*Function: outputStatsToLog()
*Created:04/17/19
*Description: ouputs stats to ouput file when game is done
*
*Parameters: hits, misses, and shots by reference, and outputFile
*Returns:none
*
****************************************************/

void outputStatsToLog(int& hits, int& misses, int& shots, ofstream& outputFile) {
	double ratio = 0.0;
	
	outputFile << "Total Shots: " << shots << endl;
	outputFile << "Total Hits: " << hits << endl;
	outputFile << "Total Misses: " << misses << endl;
	ratio = hits/misses * 100;
	outputFile << "Ratio: " << ratio << endl;
		
}


	
