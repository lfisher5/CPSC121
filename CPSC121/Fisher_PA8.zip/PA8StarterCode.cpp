#include <iostream>
#include <string>
#include <cstdlib>
#include <fstream>

using namespace std;

const int NUM_ROWS = 10;
const int NUM_COLS = 10;
const int NUM_SHIPS = 5;

// lets store ship info in 3 parallel arrays
const string shipNames[] = {"carrier", "battleship", "cruiser", "submarine", "destroyer"};
const char shipSymbols[] = {'c', 'b', 'r', 's', 'd'};
// task: one more parallel array for ship sizes
const int shipSizes[] = {5, 4, 3, 3, 2};



void displayGameRules();
void waitForUserInput();
void fillArray(char[NUM_ROWS][NUM_COLS], int, int);
void printArray(const char[NUM_ROWS][NUM_COLS], int, int);
void getManualShipPlacement(char p1SolutionGrid[NUM_ROWS][NUM_COLS]);
void randomlyPlaceShips(char[NUM_ROWS][NUM_COLS]);
bool checkShipPlacement(char[NUM_ROWS][NUM_COLS]);
void playerTurn(char[NUM_ROWS][NUM_COLS], char[NUM_ROWS][NUM_COLS], char [NUM_ROWS][NUM_COLS], int x, int y, ofstream&, int&, int&, int&,int[5]);
void computerTurn(char [NUM_ROWS][NUM_COLS], char[NUM_ROWS][NUM_COLS], int x, int y, ofstream&, int&, int&, int&, int[5]);
int getShotPlayer(char p2SolutionGrid[NUM_ROWS][NUM_COLS], int&, int&);
int getShotComputer(int& x, int& y);
bool checkShot(char [NUM_ROWS][NUM_COLS], int& x, int& y, ofstream& outputFile, int& hits, int& misses, int& shots, int[5], char [NUM_ROWS][NUM_COLS]);
void checkShipSunk(char[NUM_ROWS][NUM_COLS], int&, ofstream&);
void setP2GridEqualToBlank(char[NUM_ROWS][NUM_COLS], char[NUM_ROWS][NUM_COLS]);
void writeStatsToFile(ofstream&, bool, int, int);
int shipIndex(char shipCharacter);
void outputStatsToLog(int&, int&, int&, ofstream&);




int main() {
	char p1SolutionGrid[NUM_ROWS][NUM_COLS];
	char p2SolutionGrid[NUM_ROWS][NUM_COLS];
	char emptyP2Grid[NUM_ROWS][NUM_COLS];
	char userPlacement;
	int rows = 0;
	int cols = 0;
	char shipSymbols[5];
	int x,y, firstPlayer, hits, misses, shots;
	bool winner = true;
	ofstream outputFile;
	int shipHitsP1[5] = {0, 0, 0, 0, 0};
	int shipHitsP2[5] = {0, 0, 0, 0, 0};
	
	srand(time(0));//seed random num generator
	outputFile.open("battleship.log");
	
	
	
	displayGameRules();
	waitForUserInput();
	fillArray(p1SolutionGrid, NUM_ROWS, NUM_COLS);
	fillArray(emptyP2Grid, NUM_ROWS, NUM_COLS);
	fillArray(p2SolutionGrid, NUM_ROWS, NUM_COLS);
	printArray(p1SolutionGrid, NUM_ROWS, NUM_COLS);
	setP2GridEqualToBlank(p2SolutionGrid, emptyP2Grid);
	printArray(emptyP2Grid, NUM_ROWS, NUM_COLS);
	
		cout << "Would you like to manually place your ships or have them randomly placed for you. Enter 'm' for manual or 'r' for random." << endl;
		cin >> userPlacement;
		cin.get();
			if(userPlacement == 'r') {
				cout << "Player 1's Grid: " << endl;
				randomlyPlaceShips(p1SolutionGrid);
				
		}
			else if(userPlacement == 'm') {
				
				getManualShipPlacement(p1SolutionGrid);// works!!!
				
			
		}
		setP2GridEqualToBlank(p2SolutionGrid, emptyP2Grid);
		printArray(p1SolutionGrid, NUM_ROWS, NUM_COLS);
		cout << "Player 2's Grid: " << endl;
		randomlyPlaceShips(p2SolutionGrid);
		printArray(emptyP2Grid, NUM_ROWS, NUM_COLS);
	
	firstPlayer = rand() % 2;
	
	if(firstPlayer == 0) {
		do{
			winner = true;
			cout << "Press enter to continue. blah" << endl;
			cin.get();
			system("clear");
			playerTurn(p1SolutionGrid, p2SolutionGrid, emptyP2Grid, x, y, outputFile, hits, misses, shots, shipHitsP1);
			system("clear");
			cout << "Press enter to continue. blah" << endl;
			cin.get();
			computerTurn(p1SolutionGrid, emptyP2Grid, x, y, outputFile, hits, misses, shots, shipHitsP2);
			cin.ignore();
			
			}while(winner == true);
	}
	if(firstPlayer == 1) {
		do{
		
		cout << "Press enter to continue." << endl;
			cin.get();
			winner = true;
			system("clear");
			computerTurn(p1SolutionGrid, emptyP2Grid, x, y, outputFile, hits, misses, shots, shipHitsP2);
			cout << "Press enter to continue. blah2" << endl;
			cin.get();
			system("clear");
			playerTurn(p1SolutionGrid, p2SolutionGrid, emptyP2Grid, x, y, outputFile, hits, misses, shots, shipHitsP1);
			
			}while(winner == true);
	}
	
cout << "Game over!" << endl;
	
	
	outputFile.close();
	
	return 0;
}

 
void displayGameRules() {
	cout << "**********************************************************\n\tWELCOME TO BATTLESHIP\n**********************************************************" << endl;

cout << "\n\n\n\n Battleship is a 2-player game with the other player being the computer in which each of you will place 5 different ships of varying size on a 10x10 grid and then take turns trying to hit eachothers ships one coordinate at a time untill all units of all the ships have been ""sunk"". Good luck!\n\n\n" << endl;
//FIXME: Put clear function to clear terminal window
}

void waitForUserInput() {
	cout << "Press enter to continue." << endl;
	cin.get();
	}


void printArray(const char arr[NUM_ROWS][NUM_COLS], int rows, int cols) {
	int i, j;

	cout << " ";
	for(i = 0; i < 10; i++) {
		cout << i << " ";
		}
		cout << endl;
	for (i = 0; i < rows; i++) {
		cout << i;
		for (j = 0; j < cols; j++) {
			
			cout << arr[i][j] << " ";
		}
		cout << endl;
	}

}
void fillArray(char arr[NUM_ROWS][NUM_COLS], int rows, int cols) {
	int i, j;
	
	// outer loop iterates over each row
	for (i = 0; i < rows; i++) {
		// inner loop iterates over int in arr[i] (row)
		for (j = 0; j < cols; j++) {
			arr[i][j] = '-';
		}
	}
}


void getManualShipPlacement(char p1SolutionGrid[NUM_ROWS][NUM_COLS]) {
	int i = 0;
	int j = 0;
	int k = 0;
	int y = 0;
	int x = 0;
	string input;
	int shipCoords[10];
	bool shipCheck = false;
	
	for(i = 0; i < NUM_SHIPS; i++) {
		do {
		cout << "Please enter " << shipSizes[i] << " coordinates for the " << shipNames[i] << " to be placed across." << endl;
	//	getline(cin, input);
		shipCheck = true;
		for(k = 0; k < (shipSizes[i] * 2); k += 2) {
			cin >> x >> y;
			input[k] = x;
			input[k + 1] = y;
			//p1SolutionGrid[x][y] = shipSymbols[i];
			//ship placement check:
		if(p1SolutionGrid[x][y] != '-') {
				shipCheck = false;
			}
	
		}
		if(!shipCheck) {
			cout << "Invalid Coordinates." << endl;
			}
		
	}while(shipCheck == false);
		for(k = 0; k < shipSizes[i] * 2; k += 2) {
			p1SolutionGrid[input[k]][input[k+1]] = shipSymbols[i];
}
	}
	
}

void randomlyPlaceShips(char arr[NUM_ROWS][NUM_COLS]) {
	int x, y, i, j;
	bool shipOrientation, shipHorizontal, shipCheck;
	
	shipCheck = true;
	for(i = 0; i < NUM_SHIPS; i++) {
		shipOrientation = rand() % 2;
		if(shipOrientation == 1) {
			shipHorizontal = true;
		}
		if(shipOrientation == 0) {
			shipHorizontal = false;
		}
		if(shipHorizontal == false) {
			do{
			shipCheck = true;
			y = rand() % (10 - shipSizes[i] + 1); 
			x = rand() % 10;
			
			for(j = y; j < (y + shipSizes[i]); j++) {
				if(arr[x][j] != '-') {
					shipCheck = false;
					}
	
				}
			}while(shipCheck == false);
			
			for(j = y; j < (y + shipSizes[i]); j++) {
				arr[x][j] = shipSymbols[i];
			}

		}
		if(shipHorizontal == true) {
			do{
			shipCheck = true;
			x = rand() % (10 - shipSizes[i] + 1); 
			y = rand() % 10;
			for(j = x; j < (x + shipSizes[i]); j++) {
					if(arr[j][y] != '-') {
						shipCheck = false;
						}
					}
			}while(shipCheck == false);
			
			for(j = x; j < (x + shipSizes[i]); j++) {
				arr[j][y] = shipSymbols[i];
				}
			}
		}
	}
		
void setP2GridEqualToBlank(char p2SolutionGrid[NUM_ROWS][NUM_COLS], char emptyP2Grid[NUM_ROWS][NUM_COLS]) {
	int i, j;
	
	for(i = 0; i < NUM_ROWS; i++) {
		
		for(j = 0; j < NUM_COLS; j++) {
			emptyP2Grid[i][j] = p2SolutionGrid[i][j];
			if(p2SolutionGrid[i][j] != '-') {
				emptyP2Grid[i][j] = '-';
				}
			
			}
		}
		
	}
	
void checkShipSunk(char arr[NUM_ROWS][NUM_COLS], int shipsHitP1[5], ofstream& outputFile) {
	bool winner;
	int shipSunk;
	int i, j, k;
	
	for(i = 0; i < NUM_SHIPS; i++) {
		if(shipsHitP1[i] == shipSizes[i]) {
			cout << shipNames[i] << " is sunk!" << endl; 
			
			}
		for(j = 0; j < NUM_ROWS; j++) {
			for(k = 0; k < NUM_COLS; k++) {
				if(arr[j][k] == shipSymbols[i]) {	
					winner = false;
					}
				else{
					winner = true;
					}	
			}
		
		}	
	}

}

int getShotPlayer(char p2SolutionGrid[NUM_ROWS][NUM_COLS], int& x, int& y) {

	
	cout << "Please enter coordinates for shot at computer's board" << endl;
	cin >> x;
	cin >> y;
	

	}

int getShotComputer(int& x, int& y) {
	
	x = rand() % 10;
	y = rand() % 10;
	 
	}
	
bool checkShot(char arr[NUM_ROWS][NUM_COLS], int& x, int& y, ofstream& outputFile, int& hits, int& misses, int& shots, int shipsHitP1[5], char arr2[NUM_ROWS][NUM_COLS]) {


	bool shipHit;
	char shipCharacter;
	int shipIndexNumber;

/*do{
getShotPlayer(arr2, x, y);

}while((arr2[x][y] == 'm') || (arr2 == '*'));*/
cout << "X: " << x << " Y: " << y << endl;
	
	if(arr[x][y] == '-') {
		cout << "Miss!" << endl;
		outputFile << "Shot: " << x << ", " << y << endl;
		outputFile << "Miss!"<< endl;
		misses++;
		arr2[x][y] = 'm';
		}
	else if(arr[x][y] != '-') {
		shipCharacter = arr[x][y];
		shipIndexNumber = shipIndex(shipCharacter);
		shipsHitP1[shipIndexNumber]++;
		cout << "Hit!" << endl;
		outputFile << "Shot: " << x << ", " << y << endl;
		outputFile << "Hit!"<< endl;
		hits++;
		arr2[x][y] = '*';
		}
		return shipHit;
	}
	


void playerTurn(char p1SolutionGrid[NUM_ROWS][NUM_COLS], char p2SolutionGrid[NUM_ROWS][NUM_COLS], char emptyP2Grid[NUM_ROWS][NUM_COLS], int x, int y, ofstream& outputFile, int& hits, int& misses, int& shots, int shipsHitP1[5]) {
	cout << "\n\n\nComputer's Board: " << endl;
	printArray(emptyP2Grid, NUM_ROWS, NUM_COLS);
	cout << "Player 1's Turn: " << endl;
	
	getShotPlayer(p2SolutionGrid, x, y);
		
	//do {
	//getShotPlayer(p2SolutionGrid);
	outputFile << "Player 1: " << endl;	
	//}while((p2SolutionGrid[x][y] == 'm') || (p2SolutionGrid == '*'));
	checkShot(p2SolutionGrid, x, y, outputFile, hits, misses, shots, shipsHitP1, emptyP2Grid);
	//checkShipSunk(p2SolutionGrid);
	printArray(emptyP2Grid, NUM_ROWS, NUM_COLS);
	checkShipSunk(p2SolutionGrid, shipsHitP1, outputFile);
	}
void computerTurn(char p1SolutionGrid[NUM_ROWS][NUM_COLS], char emptyP2Grid[NUM_ROWS][NUM_COLS], int x, int y, ofstream& outputFile, int& hits, int& misses, int& shots, int shipsHitP2[5]) {

	cout << "Computer's Turn: " << endl;
	getShotComputer(x, y);
	outputFile << "Player 2: " << endl;
	checkShot(p1SolutionGrid, x, y, outputFile, hits, misses, shots, shipsHitP2, p1SolutionGrid);
	printArray(p1SolutionGrid, NUM_ROWS, NUM_COLS);
	checkShipSunk(p1SolutionGrid, shipsHitP2, outputFile);
	}
	
int shipIndex(char shipCharacter) {
	int i;
	
	for(i = 0; i < NUM_SHIPS; i++) {
		if(shipSymbols[i] == shipCharacter) {
			return i;
			}
		}
		return -1;
}

void outputStatsToLog(int& hits, int& misses, int& shots, ofstream& outputFile) {
	double ratio = 0.0;
	
	outputFile << "Total Shots: " << shots << endl;
	outputFile << "Total Hits: " << hits << endl;
	outputFile << "Total Misses: " << misses << endl;
	ratio = hits/misses * 100;
	outputFile << "Ratio: " << ratio << endl;
		
	}
	
	
	
	
	
