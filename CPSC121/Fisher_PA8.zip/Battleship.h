

/*
Name: Lauren Fisher
Class: CPSC 121
Date: 04/17/19
PA: 8
Description: This program simulates a 2 player game of battleship with a computer as player 2.
Notes: Sorry that sometimes the program is left hanging, if you click enter it will work. 
*/

#ifndef BATTLESHIP_H
#define BATTLESHIP_H


#include <iostream>
#include <string>
#include <cstdlib>
#include <fstream>

using namespace std;

const int NUM_ROWS = 10;
const int NUM_COLS = 10;
const int NUM_SHIPS = 5;

//ship info in 3 parallel arrays
const string shipNames[] = {"carrier", "battleship", "cruiser", "submarine", "destroyer"};
const char shipSymbols[] = {'c', 'b', 'r', 's', 'd'};

const int shipSizes[] = {5, 4, 3, 3, 2};



void displayGameRules();
void waitForUserInput();
void fillArray(char[NUM_ROWS][NUM_COLS], int, int);
void printArray(const char[NUM_ROWS][NUM_COLS], int, int);
void getManualShipPlacement(char p1SolutionGrid[NUM_ROWS][NUM_COLS]);
void randomlyPlaceShips(char[NUM_ROWS][NUM_COLS]);
bool checkShipPlacement(char[NUM_ROWS][NUM_COLS]);
void playerTurn(char[NUM_ROWS][NUM_COLS], char[NUM_ROWS][NUM_COLS], char [NUM_ROWS][NUM_COLS], int x, int y, ofstream&, int&, int&, int&,int[5]);
void computerTurn(char [NUM_ROWS][NUM_COLS], char[NUM_ROWS][NUM_COLS], int x, int y, ofstream&, int&, int&, int&, int[5]);
int getShotPlayer(char p2SolutionGrid[NUM_ROWS][NUM_COLS], int&, int&);
int getShotComputer(int& x, int& y);
bool checkShot(char [NUM_ROWS][NUM_COLS], int& x, int& y, ofstream& outputFile, int& hits, int& misses, int& shots, int[5], char [NUM_ROWS][NUM_COLS]);
bool checkShipSunk(char[NUM_ROWS][NUM_COLS], int&, ofstream&);
void setP2GridEqualToBlank(char[NUM_ROWS][NUM_COLS], char[NUM_ROWS][NUM_COLS]);
void writeStatsToFile(ofstream&, bool, int, int);
int shipIndex(char shipCharacter);
void outputStatsToLog(int&, int&, int&, ofstream&);

#endif 
