


/*
Name: Lauren Fisher
Class: CPSC 121
Date: 04/17/19
PA: 8
Description: This program simulates a 2 player game of battleship with a computer as player 2.
Notes: Sorry that sometimes the program is left hanging, if you click enter it will work. 
*/

#include "Battleship.h"

int main() {
	char p1SolutionGrid[NUM_ROWS][NUM_COLS];//users board
	char p2SolutionGrid[NUM_ROWS][NUM_COLS];//secret board with ship placements
	char emptyP2Grid[NUM_ROWS][NUM_COLS];// displayed to user
	char userPlacement;
	int rows = 0;
	int cols = 0;
	char shipSymbols[5];
	int x,y, k, firstPlayer;
	int shots = 0;
	int hits = 0;
	int misses = 0;
	bool winner = true;
	ofstream outputFile;//battleship.log
	int shipHitsP1[5] = {0, 0, 0, 0, 0};
	int shipHitsP2[5] = {0, 0, 0, 0, 0};
	
	srand(time(0));//seed random num generator
	outputFile.open("battleship.log");//open file
	
	
	
	displayGameRules();
	waitForUserInput();
	fillArray(p1SolutionGrid, NUM_ROWS, NUM_COLS);
	fillArray(emptyP2Grid, NUM_ROWS, NUM_COLS);
	fillArray(p2SolutionGrid, NUM_ROWS, NUM_COLS);
	printArray(p1SolutionGrid, NUM_ROWS, NUM_COLS);
	setP2GridEqualToBlank(p2SolutionGrid, emptyP2Grid);
	printArray(emptyP2Grid, NUM_ROWS, NUM_COLS);
	
		cout << "Would you like to manually place your ships or have them randomly placed for you. Enter 'm' for manual or 'r' for random." << endl;
		cin >> userPlacement;
		cin.get();
			if(userPlacement == 'r') {//random
				cout << "Player 1's Grid: " << endl;
				randomlyPlaceShips(p1SolutionGrid);
				
		}
			else if(userPlacement == 'm') {//manual
				
				getManualShipPlacement(p1SolutionGrid);// works!!!
				
			
		}
		setP2GridEqualToBlank(p2SolutionGrid, emptyP2Grid);//sets empty grid equal to p2 grid and changes chars to dashes
		printArray(p1SolutionGrid, NUM_ROWS, NUM_COLS);
		cout << "Player 2's Grid: " << endl;
		randomlyPlaceShips(p2SolutionGrid);
		printArray(emptyP2Grid, NUM_ROWS, NUM_COLS);
	
	firstPlayer = rand() % 2;
	
	if(firstPlayer == 0) {// player goes first
		do{
			winner = false;
			k++;
			cout << "Press enter to continue." << endl;
			cin.get();
			system("clear");
			playerTurn(p1SolutionGrid, p2SolutionGrid, emptyP2Grid, x, y, outputFile, hits, misses, shots, shipHitsP1);
			system("clear");
			cout << "Press enter to continue." << endl;
			cin.get();
			computerTurn(p1SolutionGrid, emptyP2Grid, x, y, outputFile, hits, misses, shots, shipHitsP2);
			cin.ignore();
			
			}while(winner == false);
		}
	if(firstPlayer == 1) {//computer goes first
		do{
		k++;
		cout << "Press enter to continue." << endl;
			cin.get();
			winner = false;
			system("clear");
			computerTurn(p1SolutionGrid, emptyP2Grid, x, y, outputFile, hits, misses, shots, shipHitsP2);//computer goes
			cout << "Press enter to continue." << endl;
			cin.get();
			system("clear");
			playerTurn(p1SolutionGrid, p2SolutionGrid, emptyP2Grid, x, y, outputFile, hits, misses, shots, shipHitsP1);// player goes

			
			}while(winner == false);
	}
	
cout << "Game over!" << endl;//only when game ends
	
	outputStatsToLog(hits, misses, shots, outputFile);//writes stats
	
	outputFile.close();//closes file
	
	return 0;
}
