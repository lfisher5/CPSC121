/*
Name: Lauren Fisher
Class: CPSC121
Date: 03/20/19
Assignment: PA6
Description: This program utilizes functions to play a 2 player game of pass the pigs until a winning score is reached.
Notes: I H8 Functions :)
*/



#include <iostream>
#include <cstdlib>
#include <ctime>
#include <string>
#include "PassThePigs.h"

using namespace std;




int main() {

srand(time(0)); //seeds random number generator


int winningScore = 0;;
int turnScore = 0;
string pigPosition1 = " ";
string pigPosition2 = " ";
string rollResult = " ";
string userResponse = " ";
string userResponse2 = " ";
int turnScore2 = 0;
int gameScore1 = 0;
int gameScore2 = 0;


cout << "Welcome to my game of pass the pigs. Here are the rules of the game: "; 
displayGameRules();

getValidWinningScore();

do{
	do{
	pigPosition1 = rollPig1();

	pigPosition2 = rollPig1();

	rollResult = determineRollResult(pigPosition1, pigPosition2);

	displayRollResult(rollResult);
		if(rollResult != "Pig-Out") {
	
	turnScore += calculateRollPoints(pigPosition1, pigPosition2, rollResult);

	cout << "Your score right now is " << turnScore << " Would you like to pass or play more... enter C for continue or Q for pass..." << endl;
	cin >> userResponse;
	}
		else {// if rollResult = pigout quit
		userResponse = "Q";
		}
	
}while(userResponse != "Q");//while user wants to continue

	if(userResponse == "Q") {//if player wants to pass
	cout << "Player1 has passed pigs to Player2..." << endl;
	
	
	}
		do{//player 2 functions
		pigPosition1 = rollPig1();

		pigPosition2 = rollPig1();

		rollResult = determineRollResult(pigPosition1, pigPosition2);

		displayRollResult(rollResult);
	
			if(rollResult != "Pig-Out") {

				turnScore2 += calculateRollPoints(pigPosition1, pigPosition2, rollResult);

				cout << "Your score right now is " << turnScore2 << ". Would you like to pass or play more... enter Con for continue or Quit for pass..." << endl;
				cin >> userResponse2;
	
	}
			else{
			userResponse2 == "Quit";
	
				if(userResponse2 == "Quit") {
					cout << "Player2 has passed pigs to Player1..." << endl;
				
}}
	}while(userResponse2 != "Quit");
		}while((gameScore1 < winningScore) && (gameScore2 < winningScore));



if(gameScore1 > winningScore) {
	cout << "Congrats Player #1 you won!" << endl;
	}
if(gameScore2 > winningScore) {
	cout << "Congrats Player #2 you won!" << endl;
	}


return 0;
}


















