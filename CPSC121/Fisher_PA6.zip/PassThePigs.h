/*
Name: Lauren Fisher
Class: CPSC121
Date: 03/20/19
Assignment: PA6
Description: This program utilizes functions to play a 2 player game of pass the pigs until a winning score is reached.
Notes: I H8 Functions :)
*/


#ifndef PASSTHEPIGS_H
#define PASSTHEPIGS_H


#include <iostream>
#include <cstdlib>
#include <ctime>
#include <string>

using namespace std;

void displayGameRules();
int getValidWinningScore();
bool isValidWinningScore(int);
string rollPig1();
string determineRollResult(string pig1, string pig2);
void displayRollResult(string);
int calculateRollPoints(string pig1, string pig2, string rollResult);


#endif






