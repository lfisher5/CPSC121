/*
Name: Lauren Fisher
Class: CPSC121
Date: 03/20/19
Assignment: PA6
Description: This program utilizes functions to play a 2 player game of pass the pigs until a winning score is reached.
Notes: I H8 Functions :)
*/



#include "PassThePigs.h"

/*********************************************************************
Function:void displayGameRules()
Date Created: 03/19/19
Date Last Modified:03/20/19
Description: Displays game rules for pass the pigs
Input Parameters: none
Returns: none
**********************************************************************/






void displayGameRules() {
	cout << "In this game you will be responsible for rolling two pigs and racking up points depending on how they land. I will ask you for a number of points that you wish to play to and then you will roll until you make that many points. The pigs have dots one on each side that can roll in any of six different ways. It can be \n 1) Razorback (On its back) \n 2) Trotter (On all four feet) \n 3) Snouter (balanced on front two feet and snout) \n 4) Leaning jowler (balanced on one foot, snout, and ear) *very rare* \n 5) Side with dot down \n 6) Side with dot up \n \nResulting from these two pigs being rolled, there are various scoring combinations in order to accumulate points. When you roll a combination of rolls these are the point distributions for them: \n\n Razorback = 5 points\n Trotter = 5 points \n Snouter = 10 points \n Leaning Jowler = 15 points\n Pig lying on its side = 0 points. However, if you get two of the same thing, different points are given... \n 1) Sider (either both with spot facing up or down) = 1 point\n 2) Double Razorback = 20 points \n 3) Double Trotter = 20 points \n 4) Double Snouter = 40 points \n 5) Double Leaning Jowler = 60 points \n 6) Pig Out (both pigs on sides with dot up on one and down on the other) = 0 points for the entire turn \n ...Good Luck! "<< endl;
}

/*********************************************************************
Function:int getValidWinningScore()
Date Created: 03/19/19
Date Last Modified:03/20/19
Description: Loops until user inputs valid score between 0 and 100.
Input Parameters: none
Returns: winningScore
**********************************************************************/


int getValidWinningScore() {
	int winningScore = 0;
	bool valid = 0;
	
	

	do{//loops until valid score reached

	cout << "Please enter the number of points you would like to play to between 0 and 100." << endl;
	cin >> winningScore;
	
	valid = isValidWinningScore(winningScore);//calls function below
	
	}while(!valid);
	
	return winningScore;

}


/*********************************************************************
Function:int isValidWinningScore()
Date Created: 03/19/19
Date Last Modified:03/20/19
Description: Checks if valid winning score or not and displays message.
Input Parameters: int score
Returns: true or false
Pre: user entered winningScore
Post: true if valid or false if invalid
**********************************************************************/

bool isValidWinningScore(int score) {
	if((score <= 100) && (score > 0)) {
		cout << "Excellent you're playing to " << score << endl;
		return true;//valid
		}
	else {
		cout << "The value you put was not valid." << endl;
		return false;//invalid
		}

}

/*********************************************************************
Function:string rollPig1()
Date Created: 03/19/19
Date Last Modified:03/20/19
Description: Rolls pig when user presses enter based on frequency of rolls and displays
Input Parameters: none
Returns: pigRoll

**********************************************************************/

string rollPig1(){
	int pigRoll1 = 0;
	string pigPosition1 = " ";
	
	cin.ignore();
	cout << "Please press enter to roll pigs " << endl;
	cin.get();//wait for user input
	
	pigRoll1 = rand() % 100 + 1;//1-100 # outputted
	//use frequency of rolls to give accurate roll probability
	if((pigRoll1 <= 35) && (pigRoll1 > 0)) {
		pigPosition1 = "Side (no dot)";
		}

	else if((pigRoll1 <= 65) && (pigRoll1 > 35)) {
		pigPosition1 = "Side (dot)";
		}
		
	else if((pigRoll1 <= 87) && (pigRoll1 > 65)) {
		pigPosition1 = "Razorback";
		}
		
	else if((pigRoll1 <= 96) && (pigRoll1 > 87)) {
		pigPosition1 = "Trotter";
		}
		
	else if((pigRoll1 <= 99) && (pigRoll1 > 96)) {
		pigPosition1 = "Snouter";
		}
		
	else if((pigRoll1 <= 100) && (pigRoll1 > 99)) {
		pigPosition1 = "Leaning Jowler";
		}
	cout << "Pig Position: " << pigPosition1 << endl;
	return pigPosition1;
}

/*********************************************************************
Function:string determineRollResult(string pigPosition1, string pigPosition2)
Date Created: 03/19/19
Date Last Modified:03/20/19
Description: Determines result of roll based off both pigs being rolled
Input Parameters: pigPosition1, pigPosition2
Returns: roll Result
**********************************************************************/

string determineRollResult(string pigPosition1, string pigPosition2) {
	
	string rollResult = " ";
	
	
	if(pigPosition1 == pigPosition2) {//if pigs show same roll
	
		
		if((pigPosition1 == "Side (no dot)") && (pigPosition2 == "Side (no dot)")) {
			rollResult = "Sider";
			}
		else if((pigPosition1 == "Side (dot)") && (pigPosition2 == "Side (dot)")) {
			rollResult = "Sider";
			}
		else if((pigPosition1 == "Razorback") && (pigPosition2 == "Razorback")) {
			rollResult = "DBL-RAZR";
			}
		else if((pigPosition1 == "Trotter") && (pigPosition2 == "Trotter")) {
			rollResult = "DBL-TROT";
			}
		else if((pigPosition1 == "Snouter") && (pigPosition2 == "Snouter")) {
			rollResult = "DBL-SNOUT";
			}	
		else if((pigPosition1 == "Leaning Jowler") && (pigPosition2 == "Leaning Jowler")) {
			rollResult = "DBL-LEAN";
			}
	}
		else{//if pigs dont show same roll
	
			if(((pigPosition1 == "Side (no dot)") && (pigPosition2 == "Side (dot)")) || ((pigPosition1 == "Side (dot)") && (pigPosition2 == "Side (no dot)"))) {
		rollResult = "Pig-Out";//pig out result
		}
			else {//mixed result
			rollResult = "Mixed";
				
			}
				}
				
				return rollResult;
					}
					
/*********************************************************************
Function:void void displayRollResult(string rollResult)
Date Created: 03/20/19
Date Last Modified:03/20/19
Description: Displays roll result based off of both rolls
Input Parameters: rollResult
Returns: nothing
**********************************************************************/

void displayRollResult(string rollResult) {

	cout << "Roll Result: " << rollResult << endl;
	}
	
/*********************************************************************
Function:int calculateRollPoints(string pigPosition1, string pigPosition2, string rollResult)
Date Created: 03/20/19
Date Last Modified:03/20/19
Description: calculates points for roll result and adds to turnScore
Input Parameters: pigPosition1, pigPosition2, and rollResult
Returns: turnScore
**********************************************************************/

int calculateRollPoints(string pigPosition1, string pigPosition2, string rollResult) {
	int turnScore = 0;
	string userResponse = " ";
	string userResponse2 = " ";
	
	if(rollResult == "Sider") {
		turnScore += 1;
		}
	if(rollResult == "DBL-RAZR") {
		turnScore += 20;
		}
	if(rollResult == "DBL-TROT") {
		turnScore += 20;
		}
	if(rollResult == "DBL-SNOUT") {
		turnScore += 40;
		}	
	if(rollResult == "DBL-LEAN") {
		turnScore += 60;
		}
	if(rollResult == "Pig-Out") {
		turnScore = 0;
		
		}
	if(rollResult == "Mixed") {//if mixed result adds points
		if((pigPosition1 == "Razorback") || 					(pigPosition2 == "Razorback")) {
				turnScore += 5;
				}
		if((pigPosition1 == "Trotter") || 					(pigPosition2 == "Trotter")) {
				turnScore += 5;
				}
		if((pigPosition1 == "Snouter") || 					(pigPosition2 == "Snouter")) {
				turnScore += 10;
				}
		if((pigPosition1 == "Leaning Jowler") || 					(pigPosition2 == "Leaning Jowler")) {
				turnScore += 15;
				}
		}
		return turnScore;
		
		}
		
		





































